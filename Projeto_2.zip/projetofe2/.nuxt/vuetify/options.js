export default {"theme":{"dark":true,"themes":{"dark":{"primary":"#3f51b5","secondary":"#2196f3","accent":"#03a9f4","error":"#00bcd4","warning":"#009688","info":"#4caf50","success":"#8bc34a"}}}}
