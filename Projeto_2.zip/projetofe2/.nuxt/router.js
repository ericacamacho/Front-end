import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3a4fa26c = () => interopDefault(import('..\\pages\\About.vue' /* webpackChunkName: "pages/About" */))
const _22101f48 = () => interopDefault(import('..\\pages\\Contatos.vue' /* webpackChunkName: "pages/Contatos" */))
const _89139b12 = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _0dd3841c = () => interopDefault(import('..\\pages\\Profiles\\Profile.vue' /* webpackChunkName: "pages/Profiles/Profile" */))
const _93906d66 = () => interopDefault(import('..\\pages\\Profiles\\_id.vue' /* webpackChunkName: "pages/Profiles/_id" */))
const _e9c42ca2 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/About",
    component: _3a4fa26c,
    name: "About"
  }, {
    path: "/Contatos",
    component: _22101f48,
    name: "Contatos"
  }, {
    path: "/inspire",
    component: _89139b12,
    name: "inspire"
  }, {
    path: "/Profiles/Profile",
    component: _0dd3841c,
    name: "Profiles-Profile"
  }, {
    path: "/Profiles/:id?",
    component: _93906d66,
    name: "Profiles-id"
  }, {
    path: "/",
    component: _e9c42ca2,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
