<template>
<h1>O ID do Utilizador é : {{$route.params.id}}</h1>
</template>